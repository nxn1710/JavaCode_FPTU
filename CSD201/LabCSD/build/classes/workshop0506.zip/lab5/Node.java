package lab5;

/**
 * @date Jul 6, 2020
 * @author Nguyen Xuan Nghiep
 */
public class Node {
    int value, weight;

    public Node() {
    }

    public Node(int node, int weight) {
        this.value = node;
        this.weight = weight;
    }
    
}
