package workshop7;

/**
 * @date Mar 7, 2020
 * @author Nguyen Xuan Nghiep
 */
public interface IEmployee {
    public double salary();
}
