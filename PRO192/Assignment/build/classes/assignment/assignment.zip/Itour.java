package assignment;

/**
 * @date Mar 15, 2020
 * @author Nguyen Xuan Nghiep
 */
public interface Itour {

    public double tourCharge();
}
