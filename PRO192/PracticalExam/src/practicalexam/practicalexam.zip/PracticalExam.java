package practicalexam;

/**
 * @date Apr 2, 2020
 * @author Nguyen Xuan Nghiep
 */
public class PracticalExam {

    public static void main(String[] args) {
        // TODO code application logic here
    }

}
