package practicalexam;

/**
 * @date Apr 3, 2020
 * @author Nguyen Xuan Nghiep
 */
public interface IPatient {
    double hospitalFee();
}
